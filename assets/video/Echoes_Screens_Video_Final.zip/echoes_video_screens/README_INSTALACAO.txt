ARQUIVOS DE VIDEO / SCREENS

Coloque os quatro .java em:
core/src/main/java/com/modulo06/echoesmoon/screens/

Os videos devem estar em:
assets/video/goodending.webm
assets/video/weirdending.webm
assets/video/earthdestroyed.webm

Fluxo:
- Rota normal em Aharin -> video/goodending.webm
- Rota estranha em Aharin -> video/weirdending.webm
- Morte/Game Over -> video/earthdestroyed.webm

Nao use assets/ no caminho do Gdx.files.internal().
