ECHOES MOON / ECHOES EM MARTE - FULL MERGED SOURCE
===================================================

Este pacote e a consolidacao dos arquivos Java fornecidos e dos patches feitos nesta conversa.
Ele foi organizado para existir UMA unica classe por nome/package, evitando os erros de duplicate class.

ESTRUTURA
---------
core/src/main/java/com/modulo06/echoesmoon/
  EchoesMoonGame.java
  entities/
  screens/
  systems/

PRINCIPAIS ALTERACOES CONSOLIDADAS
-----------------------------------
- Inventario persistente com I.
- Chaves CHAVE_LUA / CHAVE_MARTE / CHAVE_TITA / CHAVE_LUZ.
- Save persistente de fase, inventario e progressao.
- Bosses Luna/Marte/Tita com IA de perseguicao + windup + arremesso de rocha.
- Boss Calisto com 3 formas.
- Upgrade de arma/armadura por abates.
- Comida e pedras com colisao e spawn protegido do player.
- HUD de boss e status de inventario.
- Intro em viewport 800x600.
- Aharin com 3 falas.
- Rota estranha com limiar elevado (100 abates + arma/armadura max).
- Aviso de ativacao da rota estranha.
- goodending.webm / weirdending.webm via VideoCutsceneScreen.
- death.webm na tela de morte.
- Fallback quando gdx-video nao estiver instalado.
- DialogSystem protegido contra portrait null.
- Sprites dos bosses sao opcionais; sem PNG o jogo usa fallback por ShapeRenderer.

ASSETS ESPERADOS (OPCIONAIS/NECESSARIOS CONFORME A CENA)
----------------------------------------------------------
assets/food.png
assets/pedra.png
assets/boss_lua.png
assets/boss_marte.png
assets/boss_tita.png
assets/boss_calisto.png
assets/video/goodending.webm
assets/video/weirdending.webm
assets/video/death.webm

IMPORTANTE
----------
- Este pacote contem a camada de codigo Java consolidada.
- Os uploads fornecidos nesta conversa nao incluiram build.gradle/settings.gradle nem a pasta assets completa,
  portanto esses arquivos nao foram inventados aqui.
- Para video WebM, o projeto precisa da dependencia gdx-video compativel com a versao de libGDX usada pelo projeto.
- Abra este codigo como substituicao da pasta core/src/main/java do projeto original.
