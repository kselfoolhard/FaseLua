package com.modulo06.echoesmoon.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

/** Recurso visual reutilizavel para as arenas dos bosses. */
public final class PlayerVisuals {
    private final Animation<TextureRegion> idle;
    private final Animation<TextureRegion> walk;
    private final Animation<TextureRegion> attack;
    private final Rectangle bounds;

    private float stateTime = 0f;
    private boolean moving = false;
    private float attackTime = 0f;

    private Texture idleTexture;
    private Texture walkTexture;
    private Texture attackTexture;

    public PlayerVisuals(Rectangle bounds) {
        this.bounds = bounds;
        idleTexture = loadOptional("player_lunar.png");
        walkTexture = loadOptional("player_lunar_walk.png");
        attackTexture = loadOptional("player_lunar_slash.png");

        idle = makeAnimation(idleTexture, 0.20f);
        walk = makeAnimation(walkTexture, 0.12f);
        attack = makeAnimation(attackTexture, 0.08f);
    }

    private Texture loadOptional(String path) {
        try {
            if (!Gdx.files.internal(path).exists()) return null;
            return new Texture(path);
        } catch (Exception ignored) {
            return null;
        }
    }

    private Animation<TextureRegion> makeAnimation(Texture texture, float frameDuration) {
        if (texture == null) return null;

        int frameCount = 4;
        int frameWidth = texture.getWidth() >= frameCount
                ? texture.getWidth() / frameCount
                : texture.getWidth();

        if (frameWidth <= 0) return null;

        TextureRegion[][] rows = TextureRegion.split(
                texture,
                frameWidth,
                texture.getHeight()
        );

        if (rows.length == 0 || rows[0].length == 0) return null;
        return new Animation<>(frameDuration, rows[0]);
    }

    public void update(float delta, boolean moving) {
        this.moving = moving;
        stateTime += delta;
        if (attackTime > 0f) attackTime -= delta;
    }

    /** Compatibilidade com as telas que chamam draw(batch, moving). */
    public void draw(SpriteBatch batch, boolean movingNow) {
        this.moving = movingNow;
        draw(batch);
    }

    /** Desenha a animacao adequada ao estado atual. */
    public void draw(SpriteBatch batch) {
        Animation<TextureRegion> animation;

        if (attackTime > 0f && attack != null) {
            animation = attack;
        } else if (moving && walk != null) {
            animation = walk;
        } else {
            animation = idle;
        }

        if (animation == null) return;

        boolean looping = attackTime <= 0f || animation != attack;
        TextureRegion frame = animation.getKeyFrame(stateTime, looping);
        batch.draw(frame, bounds.x, bounds.y, bounds.width, bounds.height);
    }

    /** Dispara a animacao de ataque sem depender de uma textura existir. */
    public void triggerAttack() {
        attackTime = attack != null ? Math.max(0.18f, attack.getAnimationDuration()) : 0.18f;
        stateTime = 0f;
    }

    public void dispose() {
        if (idleTexture != null) idleTexture.dispose();
        if (walkTexture != null) walkTexture.dispose();
        if (attackTexture != null) attackTexture.dispose();
    }
}
