$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $root "core/src/main/java/com/modulo06/echoesmoon/screens/CallistoScreen.java"
$dst = Join-Path $root "core/src/main/java/com/modulo06/echoesmoon/screens/CallistoScreen.java"
if (!(Test-Path $src)) { throw "CallistoScreen.java não encontrado em $src" }
$backupDir = Join-Path $root ("_ECHOES_BACKUP_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
Copy-Item $dst (Join-Path $backupDir "CallistoScreen.java") -Force
Copy-Item $src $dst -Force
Write-Host "CallistoScreen atualizado. Backup em: $backupDir"
