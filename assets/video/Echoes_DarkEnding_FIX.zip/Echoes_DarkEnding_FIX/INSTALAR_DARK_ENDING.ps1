$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $root 'core\src\main\java\com\modulo06\echoesmoon\screens\DarkEndingScreen.java'
if (-not (Test-Path $target)) { throw "Nao encontrei o projeto core em $root" }
$backup = Join-Path (Split-Path $target) ('DarkEndingScreen.java.bak_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
Copy-Item $target $backup -Force
Copy-Item (Join-Path $root 'screens\DarkEndingScreen.java') $target -Force
Write-Host "OK: DarkEndingScreen corrigido. Backup: $backup"
